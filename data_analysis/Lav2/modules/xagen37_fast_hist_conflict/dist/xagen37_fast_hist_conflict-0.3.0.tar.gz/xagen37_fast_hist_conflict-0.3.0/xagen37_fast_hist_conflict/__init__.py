'''
xagen37_fast_hist_conflict.

Dummy module for doing lab.
'''

__version__ = "0.3.0"
__author__ = 'Alexander Sofrygin'