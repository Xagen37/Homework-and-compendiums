'''
xagen37_fast_hist.

Dummy module for doing lab.
'''

__version__ = "0.6.0"
__author__ = 'Alexander Sofrygin'